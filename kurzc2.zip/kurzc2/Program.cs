﻿using System;

namespace kurzc2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i,j;
            Console.WriteLine("Napište něco zde:");
            var something = Console.ReadLine();
            

            for (i = 0; i<10; i++) 
            {
                Console.WriteLine(something);
                

            }
            for (j = 0; j < 10; j++)
            {
                Console.WriteLine(something + j);
                if (j == 10) {

                    break;
                        }
            
               

            }
        }
    }
}
