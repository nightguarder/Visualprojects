﻿using System;
using System.Globalization;
using System.Threading;


namespace kurzC
{
    class Program
    {
        static void Main(string[] args)

        {
            Console.WriteLine("Zadejte prosím Vaše slovo");
            Console.WriteLine("Pište zde:");


            {
                string uzivatel;

                uzivatel = Console.ReadLine();

                string vystup;
                vystup = uzivatel + "," + uzivatel + "," + uzivatel + "," + uzivatel + "," + uzivatel + "," + uzivatel + "!";

                for (int i = 0; i < 5; i++) ;
                Console.WriteLine("Čekejte prosim...");
                Thread.Sleep(3000);
                Console.WriteLine(vystup);
                Console.WriteLine("tak zatim"); 
                Console.ReadKey();

            
            
            }






        }
    }
}
